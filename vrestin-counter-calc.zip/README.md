# +1/+1 Counter Calculator
A simple calculator to track +1/+1 counters in Magic: The Gathering, based on selected cards.