import CounterCalculator from "./CounterCalculator";
export default function App() {
  return <CounterCalculator />;
}